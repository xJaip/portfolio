Repositorio en
https://github.com/xJaip/portfolio


Para ejecutar en máquina local debe instalar dependencias con

npm install

y para ejecutar 

npm run dev
